import 'package:flutter/material.dart';
import 'screens/yoga_session.dart';

void main() => runApp(const YogaApp());

class YogaApp extends StatelessWidget {
  const YogaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yoga Session',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: const YogaSession(),
    );
  }
}
