import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import '../models/pose.dart';
import '../widgets/pose_view.dart';

class YogaSession extends StatefulWidget {
  const YogaSession({super.key});

  @override
  State<YogaSession> createState() => _YogaSessionState();
}

class _YogaSessionState extends State<YogaSession> {
  final AudioPlayer _player = AudioPlayer();
  List<Pose> _poses = [];
  int _currentPoseIndex = 0;
  bool _isPlaying = true;

  @override
  void initState() {
    super.initState();
    _loadSession();
  }

  Future<void> _loadSession() async {
    final data = await rootBundle.loadString('assets/poses.json');
    final List<dynamic> jsonResult = json.decode(data);
    _poses = jsonResult.map((json) => Pose.fromJson(json)).toList();
    _startPose();
  }

  Future<void> _startPose() async {
    if (_currentPoseIndex >= _poses.length) return;

    final pose = _poses[_currentPoseIndex];
    await _player.play(AssetSource(pose.audio));
    Future.delayed(Duration(seconds: pose.duration), () {
      if (mounted && _isPlaying) {
        setState(() => _currentPoseIndex++);
        _startPose();
      }
    });
  }

  void _togglePlayPause() {
    setState(() => _isPlaying = !_isPlaying);
    if (_isPlaying) {
      _startPose();
    } else {
      _player.pause();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_poses.isEmpty || _currentPoseIndex >= _poses.length) {
      return const Center(child: CircularProgressIndicator());
    }

    final pose = _poses[_currentPoseIndex];
    return Scaffold(
      appBar: AppBar(title: const Text('Yoga Session')),
      body: Center(child: PoseView(pose: pose)),
      floatingActionButton: FloatingActionButton(
        onPressed: _togglePlayPause,
        child: Icon(_isPlaying ? Icons.pause : Icons.play_arrow),
      ),
    );
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
