import 'package:flutter/material.dart';
import '../models/pose.dart';

class PoseView extends StatelessWidget {
  final Pose pose;

  const PoseView({required this.pose, super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(pose.image),
        const SizedBox(height: 20),
        Text(pose.name, style: const TextStyle(fontSize: 24)),
      ],
    );
  }
}
